# To Do List with User Registration & Login

To Do List with user registration, login, search and CRUD with Django.

Class Based Views links:

- [Django CBV Documentation](https://docs.djangoproject.com/en/4.0/ref/class-based-views/)
- [Django Views Source code](https://github.com/django/django/tree/master/django/views/generic)
- [Detailed descriptions for each of Django's class-based views.](http://ccbv.co.uk/)

![](https://i.imgur.com/bzwUJnL.gif)
